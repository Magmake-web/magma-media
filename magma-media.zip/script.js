function addComment(event, blogId) {
  event.preventDefault();
  const form = event.target;
  const input = form.querySelector('input');
  const commentText = input.value.trim();
  if (!commentText) return;

  const commentList = document.getElementById('comments-' + blogId);
  const comment = document.createElement('p');
  comment.textContent = commentText;
  commentList.appendChild(comment);

  // Save in localStorage
  const saved = JSON.parse(localStorage.getItem(blogId) || "[]");
  saved.push(commentText);
  localStorage.setItem(blogId, JSON.stringify(saved));

  input.value = "";
}

// Load saved comments
window.onload = () => {
  ['blog1'].forEach(blogId => {
    const commentList = document.getElementById('comments-' + blogId);
    const saved = JSON.parse(localStorage.getItem(blogId) || "[]");
    saved.forEach(text => {
      const comment = document.createElement('p');
      comment.textContent = text;
      commentList.appendChild(comment);
    });
  });
};
